<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Servico;
use Illuminate\Http\Request;

class ServicoController extends Controller
{
    /**
     * Lista os serviços cadastrados.
     */
    public function index()
    {
        $servicos = Servico::orderBy('nome')->paginate(15);

        return view('admin.servicos.index', compact('servicos'));
    }

    /**
     * Formulário de criação.
     */
    public function create()
    {
        return view('admin.servicos.create');
    }

    /**
     * Salva um novo serviço.
     */
    public function store(Request $request)
    {
        $dados = $this->validar($request);

        Servico::create($dados);

        return redirect()
            ->route('admin.servicos.index')
            ->with('sucesso', 'Serviço cadastrado.');
    }

    /**
     * Formulário de edição.
     */
    public function edit(Servico $servico)
    {
        return view('admin.servicos.edit', compact('servico'));
    }

    /**
     * Atualiza o serviço.
     */
    public function update(Request $request, Servico $servico)
    {
        $dados = $this->validar($request);

        $servico->update($dados);

        return redirect()
            ->route('admin.servicos.index')
            ->with('sucesso', 'Serviço atualizado.');
    }

    /**
     * Exclui um serviço.
     */
    public function destroy(Servico $servico)
    {
        $servico->delete();

        return back()->with('sucesso', 'Serviço removido.');
    }

    /**
     * Centraliza a validação do formulário.
     */
    private function validar(Request $request): array
    {
        return $request->validate([
            'nome' => ['required', 'string', 'max:120'],
            'descricao' => ['nullable', 'string', 'max:1000'],
            'unidade' => ['required', 'string', 'max:20'],
            'preco' => ['required', 'numeric', 'min:0'],
            'ativo' => ['nullable', 'boolean'],
        ]);
    }
}
