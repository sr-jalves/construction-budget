<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Servico;
use App\Models\Orcamento;

class DashboardController extends Controller
{
    /**
     * Exibe um resumo administrativo.
     */
    public function index()
    {
        return view('admin.dashboard', [
            'servicos' => Servico::count(),
            'servicosAtivos' => Servico::where('ativo', true)->count(),
            'orcamentos' => Orcamento::count(),
            'orcamentosPendentes' => Orcamento::where('status', 'pendente')->count(),
        ]);
    }
}
