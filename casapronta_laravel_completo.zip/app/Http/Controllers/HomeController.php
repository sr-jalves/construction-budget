<?php

namespace App\Http\Controllers;

use App\Models\Servico;

class HomeController extends Controller
{
    /**
     * Exibe a página inicial.
     *
     * Busca apenas serviços ativos para que o cliente
     * não veja serviços desativados pelo administrador.
     */
    public function index()
    {
        $servicos = Servico::where('ativo', true)
            ->orderBy('nome')
            ->get();

        return view('home', compact('servicos'));
    }
}
