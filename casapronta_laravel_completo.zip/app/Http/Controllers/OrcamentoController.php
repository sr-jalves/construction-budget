<?php

namespace App\Http\Controllers;

use App\Models\Servico;
use App\Models\Orcamento;
use Illuminate\Http\Request;
use Illuminate\Validation\ValidationException;

class OrcamentoController extends Controller
{
    /**
     * Recebe o orçamento enviado pelo cliente.
     *
     * O servidor recalcula todos os preços usando os valores
     * atuais do banco. Isso é importante para não confiar
     * somente no JavaScript do navegador.
     */
    public function store(Request $request)
    {
        $dados = $request->validate([
            'nome' => ['required', 'string', 'max:120'],
            'telefone' => ['required', 'string', 'max:30'],
            'email' => ['nullable', 'email', 'max:120'],
            'endereco' => ['nullable', 'string', 'max:255'],
            'observacoes' => ['nullable', 'string', 'max:2000'],
            'itens' => ['required', 'array', 'min:1'],
            'itens.*.servico_id' => ['required', 'integer', 'exists:servicos,id'],
            'itens.*.quantidade' => ['required', 'numeric', 'min:0.01', 'max:100000'],
        ]);

        $itensCalculados = [];
        $total = 0;

        foreach ($dados['itens'] as $item) {
            $servico = Servico::where('id', $item['servico_id'])
                ->where('ativo', true)
                ->first();

            if (!$servico) {
                throw ValidationException::withMessages([
                    'itens' => 'Um dos serviços selecionados não está mais disponível.'
                ]);
            }

            $quantidade = (float) $item['quantidade'];
            $subtotal = $quantidade * (float) $servico->preco;

            $itensCalculados[] = [
                'servico_id' => $servico->id,
                'nome' => $servico->nome,
                'unidade' => $servico->unidade,
                'quantidade' => $quantidade,
                'preco_unitario' => (float) $servico->preco,
                'subtotal' => round($subtotal, 2),
            ];

            $total += $subtotal;
        }

        Orcamento::create([
            'nome' => $dados['nome'],
            'telefone' => $dados['telefone'],
            'email' => $dados['email'] ?? null,
            'endereco' => $dados['endereco'] ?? null,
            'observacoes' => $dados['observacoes'] ?? null,
            'itens' => $itensCalculados,
            'total' => round($total, 2),
            'status' => 'pendente',
        ]);

        return back()->with('sucesso', 'Orçamento enviado com sucesso!');
    }
}
