<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Orcamento extends Model
{
    /*
    |--------------------------------------------------------------------------
    | Campos que podem ser preenchidos
    |--------------------------------------------------------------------------
    */

    protected $fillable = [
        'nome',
        'telefone',
        'email',
        'endereco',
        'observacoes',
        'itens',
        'total',
        'status',
    ];

    /*
    | O campo itens será armazenado em JSON e convertido
    | automaticamente para array pelo Laravel.
    */

    protected $casts = [
        'itens' => 'array',
        'total' => 'decimal:2',
    ];
}
