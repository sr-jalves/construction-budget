<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Servico extends Model
{
    /*
    |--------------------------------------------------------------------------
    | Campos permitidos para preenchimento em massa
    |--------------------------------------------------------------------------
    |
    | O administrador poderá editar estes campos pelo formulário.
    |
    */

    protected $fillable = [
        'nome',
        'descricao',
        'unidade',
        'preco',
        'ativo',
    ];

    /*
    |--------------------------------------------------------------------------
    | Conversão automática de tipos
    |--------------------------------------------------------------------------
    */

    protected $casts = [
        'preco' => 'decimal:2',
        'ativo' => 'boolean',
    ];
}
