<?php

/*
|--------------------------------------------------------------------------
| Autenticacao
|--------------------------------------------------------------------------
|
| O projeto inclui Laravel Breeze como dependencia. Em uma instalacao
| limpa, execute:
|
| php artisan breeze:install blade
|
| para publicar as telas e rotas completas de login/cadastro.
|
*/
