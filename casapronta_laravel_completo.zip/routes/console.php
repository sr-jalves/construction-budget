<?php

use Illuminate\Support\Facades\Artisan;

Artisan::command('casapronta:info', function () {
    $this->info('CasaPronta - sistema de orcamentos de manutencao residencial.');
})->purpose('Exibe informacoes do projeto');
