<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\HomeController;
use App\Http\Controllers\OrcamentoController;
use App\Http\Controllers\Admin\ServicoController;
use App\Http\Controllers\Admin\DashboardController;

/*
|--------------------------------------------------------------------------
| Rotas públicas
|--------------------------------------------------------------------------
|
| Aqui ficam as páginas que qualquer visitante pode acessar.
|
*/

Route::get('/', [HomeController::class, 'index'])
    ->name('home');

Route::post('/orcamento', [OrcamentoController::class, 'store'])
    ->name('orcamento.store');

/*
|--------------------------------------------------------------------------
| Área administrativa
|--------------------------------------------------------------------------
|
| O middleware auth impede que usuários não autenticados
| acessem o painel.
|
*/

Route::middleware(['auth'])->prefix('admin')->name('admin.')->group(function () {

    Route::get('/', [DashboardController::class, 'index'])
        ->name('dashboard');

    // CRUD completo dos serviços.
    Route::resource('servicos', ServicoController::class);
});

require __DIR__.'/auth.php';
