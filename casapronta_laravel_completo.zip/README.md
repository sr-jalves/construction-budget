# CasaPronta — Projeto Laravel completo

Sistema de prestação de serviços e orçamento para manutenção residencial.

## Incluído

- `artisan`
- `composer.json`
- `.gitignore`
- `.env.example`
- estrutura `app/`, `bootstrap/`, `config/`, `database/`, `public/`, `resources/`, `routes/`, `storage/`, `tests/`
- Models, Controllers, migrations e seeders
- Calculadora de orçamento
- CRUD de serviços
- Painel administrativo
- Front-end Blade + Vite
- Dependência do Laravel Breeze para autenticação

## Instalação

Requisitos:
- PHP 8.2+
- Composer
- Node.js/npm

Na pasta do projeto:

```bash
composer install
cp .env.example .env
php artisan key:generate
php artisan migrate --seed
npm install
npm run build
php artisan serve
```

Windows PowerShell:

```powershell
composer install
Copy-Item .env.example .env
php artisan key:generate
php artisan migrate --seed
npm install
npm run build
php artisan serve
```

Abra `http://127.0.0.1:8000`.

## Login administrativo

```text
E-mail: admin@casapronta.local
Senha: password
```

Altere a senha antes de produção.

## Autenticação

O `composer.json` já inclui Laravel Breeze. Para publicar as telas de autenticação:

```bash
php artisan breeze:install blade
npm install
npm run build
```

## Banco

Por padrão, usa SQLite:

```env
DB_CONNECTION=sqlite
DB_DATABASE=database/database.sqlite
```

Para MySQL/MariaDB, ajuste o `.env`.

## Preços

Os preços dos serviços ficam na tabela `servicos` e podem ser alterados pelo painel administrativo. O cliente calcula no navegador, mas o servidor recalcula tudo usando o preço atual do banco antes de gravar o orçamento.

## Importante

`vendor/` e `node_modules/` não são incluídos no ZIP. São diretórios gerados por:

```bash
composer install
npm install
```
