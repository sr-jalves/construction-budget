@extends('layouts.app')

@section('content')
<section class="container section">
    <h1>Painel administrativo</h1>

    <div class="stats">
        <div><span>Serviços</span><strong>{{ $servicos }}</strong></div>
        <div><span>Ativos</span><strong>{{ $servicosAtivos }}</strong></div>
        <div><span>Orçamentos</span><strong>{{ $orcamentos }}</strong></div>
        <div><span>Pendentes</span><strong>{{ $orcamentosPendentes }}</strong></div>
    </div>

    <a class="btn primary" href="{{ route('admin.servicos.index') }}">
        Gerenciar serviços
    </a>
</section>
@endsection
