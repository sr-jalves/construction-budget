@extends('layouts.app')

@section('content')
<section class="container section narrow">
    <h1>Novo serviço</h1>

    <form method="POST" action="{{ route('admin.servicos.store') }}" class="admin-form">
        @csrf
        @include('admin.servicos.form')
    </form>
</section>
@endsection
