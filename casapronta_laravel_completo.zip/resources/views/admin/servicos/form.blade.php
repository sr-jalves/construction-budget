<label>
    Nome
    <input name="nome" required value="{{ old('nome', $servico->nome ?? '') }}">
</label>

<label>
    Descrição
    <textarea name="descricao" rows="4">{{ old('descricao', $servico->descricao ?? '') }}</textarea>
</label>

<label>
    Unidade
    <select name="unidade">
        @foreach(['m²', 'metro', 'unidade', 'hora', 'serviço'] as $unidade)
            <option value="{{ $unidade }}"
                @selected(old('unidade', $servico->unidade ?? 'm²') === $unidade)>
                {{ $unidade }}
            </option>
        @endforeach
    </select>
</label>

<label>
    Preço
    <input type="number" name="preco" step="0.01" min="0"
           required value="{{ old('preco', $servico->preco ?? '') }}">
</label>

<label class="checkbox">
    <input type="checkbox" name="ativo" value="1"
        @checked(old('ativo', $servico->ativo ?? true))>
    Serviço ativo
</label>

<button class="btn primary" type="submit">Salvar</button>
<a class="btn" href="{{ route('admin.servicos.index') }}">Cancelar</a>
