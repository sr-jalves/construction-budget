@extends('layouts.app')

@section('content')
<section class="container section">
    <div class="section-title">
        <div>
            <h1>Serviços</h1>
            <p>Altere preços e disponibilidade sem editar o código.</p>
        </div>
        <a class="btn primary" href="{{ route('admin.servicos.create') }}">Novo serviço</a>
    </div>

    <div class="table-wrap">
        <table>
            <thead>
                <tr>
                    <th>Serviço</th>
                    <th>Unidade</th>
                    <th>Preço</th>
                    <th>Status</th>
                    <th>Ações</th>
                </tr>
            </thead>
            <tbody>
                @foreach($servicos as $servico)
                    <tr>
                        <td>{{ $servico->nome }}</td>
                        <td>{{ $servico->unidade }}</td>
                        <td>R$ {{ number_format($servico->preco, 2, ',', '.') }}</td>
                        <td>{{ $servico->ativo ? 'Ativo' : 'Inativo' }}</td>
                        <td class="actions">
                            <a href="{{ route('admin.servicos.edit', $servico) }}">Editar</a>

                            <form method="POST" action="{{ route('admin.servicos.destroy', $servico) }}"
                                  onsubmit="return confirm('Excluir este serviço?')">
                                @csrf
                                @method('DELETE')
                                <button type="submit">Excluir</button>
                            </form>
                        </td>
                    </tr>
                @endforeach
            </tbody>
        </table>
    </div>

    {{ $servicos->links() }}
</section>
@endsection
