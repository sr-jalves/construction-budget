@extends('layouts.app')

@section('content')
<section class="container section narrow">
    <h1>Editar serviço</h1>

    <form method="POST" action="{{ route('admin.servicos.update', $servico) }}" class="admin-form">
        @csrf
        @method('PUT')
        @include('admin.servicos.form')
    </form>
</section>
@endsection
