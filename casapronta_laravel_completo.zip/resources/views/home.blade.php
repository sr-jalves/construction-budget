@extends('layouts.app')

@section('content')

<section class="hero">
    <div class="container">
        <p class="eyebrow">MANUTENÇÃO RESIDENCIAL</p>
        <h1>Cuide da sua casa sem complicação.</h1>
        <p>Escolha os serviços, informe a quantidade e veja uma estimativa do orçamento.</p>
    </div>
</section>

<section class="container section">
    <div class="section-title">
        <div>
            <h2>Monte seu orçamento</h2>
            <p>Os preços podem ser alterados pelo administrador.</p>
        </div>
    </div>

    <form method="POST" action="{{ route('orcamento.store') }}" id="orcamentoForm">
        @csrf

        <div class="service-grid">
            @foreach($servicos as $servico)
                <article class="service-card"
                    data-id="{{ $servico->id }}"
                    data-price="{{ $servico->preco }}"
                    data-unit="{{ $servico->unidade }}">

                    <div class="service-icon">🔧</div>
                    <h3>{{ $servico->nome }}</h3>

                    @if($servico->descricao)
                        <p>{{ $servico->descricao }}</p>
                    @endif

                    <strong>R$ {{ number_format($servico->preco, 2, ',', '.') }}
                        / {{ $servico->unidade }}</strong>

                    <label>
                        Quantidade
                        <input
                            type="number"
                            class="quantity"
                            min="0"
                            step="0.01"
                            value="0"
                            inputmode="decimal"
                        >
                    </label>

                    <div class="subtotal">
                        R$ <span>0,00</span>
                    </div>
                </article>
            @endforeach
        </div>

        <section class="quote-box">
            <h2>Seus dados</h2>

            <div class="form-grid">
                <label>
                    Nome
                    <input name="nome" required maxlength="120">
                </label>

                <label>
                    Telefone / WhatsApp
                    <input name="telefone" required maxlength="30">
                </label>

                <label>
                    E-mail
                    <input type="email" name="email" maxlength="120">
                </label>

                <label>
                    Endereço
                    <input name="endereco" maxlength="255">
                </label>
            </div>

            <label>
                Observações
                <textarea name="observacoes" rows="4"
                    placeholder="Conte detalhes do serviço, medidas, estado da parede etc."></textarea>
            </label>

            <div id="hiddenItems"></div>

            <div class="total">
                <span>Total estimado</span>
                <strong>R$ <span id="total">0,00</span></strong>
            </div>

            <button class="btn primary" type="submit">
                Solicitar orçamento
            </button>
        </section>
    </form>
</section>

@endsection
