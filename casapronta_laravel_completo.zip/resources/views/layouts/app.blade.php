<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>{{ $title ?? 'CasaPronta Serviços' }}</title>

    @vite(['resources/css/app.css', 'resources/js/app.js'])
</head>
<body>
<header class="topbar">
    <div class="container nav">
        <a href="{{ route('home') }}" class="logo">CasaPronta</a>

        <nav>
            <a href="{{ route('home') }}">Serviços</a>

            @auth
                <a href="{{ route('admin.dashboard') }}">Painel</a>
            @else
                <a href="/login">Administrador</a>
            @endauth
        </nav>
    </div>
</header>

<main>
    @if(session('sucesso'))
        <div class="container">
            <div class="alert success">{{ session('sucesso') }}</div>
        </div>
    @endif

    @yield('content')
</main>

<footer>
    <div class="container">
        <p>© {{ date('Y') }} CasaPronta Serviços</p>
    </div>
</footer>
</body>
</html>
