A autenticação é instalada pelo Laravel Breeze.

Execute:
composer require laravel/breeze --dev
php artisan breeze:install blade
npm install
npm run build

O comando criará automaticamente as views, rotas e controllers de autenticação.
