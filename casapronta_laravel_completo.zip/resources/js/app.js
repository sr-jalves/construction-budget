import './bootstrap';

/*
|--------------------------------------------------------------------------
| Calculadora de orçamento
|--------------------------------------------------------------------------
|
| O JavaScript calcula o total imediatamente para melhorar a experiência.
| IMPORTANTE: o servidor também recalcula os valores antes de salvar,
| portanto o cálculo do navegador não é usado como fonte de verdade.
|
*/

document.addEventListener('DOMContentLoaded', () => {
    const cards = document.querySelectorAll('.service-card');
    const totalElement = document.querySelector('#total');
    const hiddenItems = document.querySelector('#hiddenItems');

    if (!cards.length || !totalElement || !hiddenItems) {
        return;
    }

    const moeda = (valor) => {
        return Number(valor).toLocaleString('pt-BR', {
            minimumFractionDigits: 2,
            maximumFractionDigits: 2
        });
    };

    const atualizar = () => {
        let total = 0;
        hiddenItems.innerHTML = '';

        cards.forEach((card) => {
            const id = card.dataset.id;
            const price = Number(card.dataset.price);
            const quantityInput = card.querySelector('.quantity');
            const subtotalElement = card.querySelector('.subtotal span');

            const quantity = Number(quantityInput.value || 0);
            const subtotal = price * quantity;

            subtotalElement.textContent = moeda(subtotal);
            total += subtotal;

            // Somente envia para o Laravel itens com quantidade maior que zero.
            if (quantity > 0) {
                hiddenItems.insertAdjacentHTML('beforeend', `
                    <input type="hidden" name="itens[${id}][servico_id]" value="${id}">
                    <input type="hidden" name="itens[${id}][quantidade]" value="${quantity}">
                `);
            }
        });

        totalElement.textContent = moeda(total);
    };

    cards.forEach((card) => {
        card.querySelector('.quantity')
            .addEventListener('input', atualizar);
    });

    atualizar();
});
