<?php

namespace Database\Seeders;

use App\Models\Servico;
use Illuminate\Database\Seeder;

class ServicoSeeder extends Seeder
{
    /**
     * Insere serviços iniciais para o sistema já começar funcionando.
     *
     * Os valores são exemplos e devem ser ajustados para sua região
     * e para o custo real da mão de obra/material.
     */
    public function run(): void
    {
        $servicos = [
            ['nome' => 'Pintura de parede', 'descricao' => 'Pintura interna ou externa.', 'unidade' => 'm²', 'preco' => 18],
            ['nome' => 'Emassamento de parede', 'descricao' => 'Aplicação e preparação com massa.', 'unidade' => 'm²', 'preco' => 15],
            ['nome' => 'Reboco', 'descricao' => 'Execução de reboco convencional.', 'unidade' => 'm²', 'preco' => 30],
            ['nome' => 'Assentamento de piso', 'descricao' => 'Instalação de piso cerâmico.', 'unidade' => 'm²', 'preco' => 35],
            ['nome' => 'Assentamento de revestimento', 'descricao' => 'Instalação de revestimentos de parede.', 'unidade' => 'm²', 'preco' => 38],
            ['nome' => 'Pintura de teto', 'descricao' => 'Pintura de teto.', 'unidade' => 'm²', 'preco' => 20],
            ['nome' => 'Impermeabilização', 'descricao' => 'Serviço de impermeabilização.', 'unidade' => 'm²', 'preco' => 45],
            ['nome' => 'Pequenos reparos', 'descricao' => 'Serviços diversos de manutenção.', 'unidade' => 'hora', 'preco' => 50],
        ];

        foreach ($servicos as $servico) {
            Servico::create($servico);
        }
    }
}
