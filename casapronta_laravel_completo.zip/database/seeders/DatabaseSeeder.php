<?php

namespace Database\Seeders;

use App\Models\User;
use Illuminate\Database\Seeder;

class DatabaseSeeder extends Seeder
{
    public function run(): void
    {
        /*
         * Cria um usuário administrativo para acessar o painel.
         *
         * Em produção, troque imediatamente esta senha.
         */
        User::factory()->create([
            'name' => 'Administrador',
            'email' => 'admin@casapronta.local',
            'password' => bcrypt('password'),
        ]);

        $this->call(ServicoSeeder::class);
    }
}
